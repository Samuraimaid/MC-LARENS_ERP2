Catálogo de productos Auxbeam — Luces de conducción (Driving Lights)
=======================================================================

Contenido de este paquete
-------------------------
- catalogo.json     Array JSON con todos los productos y campos para importación ERP
- catalogo.xlsx     Excel con hoja "productos" (1 fila por producto) y hoja "variantes"
- imagenes/         Carpetas por handle de producto con principal.* y adicional_NN.*
- README.txt        Este archivo

Productos incluidos: 194
Imágenes descargadas correctamente (archivos): 3569
Imágenes fallidas: 7

Campos principales (catalogo.json)
----------------------------------
- id, handle, url
- nombre (español)
- sku / skus / variantes
- precio, precio_comparado
- tension_trabajo, potencia
- descripcion (español)
- especificaciones (objeto clave-valor en español)
- contenido_caja (español)
- imagen_principal, imagenes_adicionales (rutas relativas)

Cómo importar
-------------
1. Descomprimir el ZIP manteniendo la estructura de carpetas.
2. Usar catalogo.json o catalogo.xlsx según el conector ERP.
3. Mapear columnas/campos a los atributos del ERP (SKU, precio, descripción, etc.).
4. Las rutas de imagen son relativas a la raíz del catálogo (p. ej. imagenes/<handle>/principal.jpg).
5. Si un campo no estaba en la ficha original de Auxbeam, aparece como "No especificado" o vacío.

Notas
-----
- Textos traducidos automáticamente EN→ES (Argos Translate offline + mapa de claves técnicas).
  Revisar descripciones técnicas si se requiere precisión editorial.
- Códigos de serie (V-ULTRA, XP-ULTRA, etc.), unidades (W, V, LM, IP68) y SKUs se conservan.
- Fuente: https://auxbeam.com/collections/driving-light
- Generado para importación ERP de Xinon.
